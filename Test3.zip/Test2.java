
public class Test2 {
		
	void arithematicException(int a) {
		try {
			int n = a/0;
			System.out.println(n);
		}catch(ArithmeticException e) {
			System.err.println("Divide by 0");
		}
	}
	
	void nullPointerException(String s) {
		try {
			System.out.println(s.length());
		}catch(NullPointerException e) {
			System.err.println("String is null");
		}
	}
	
	void arrayIndexOutOfBoundsException(int arr[]) {
		try {
		for (int i = 0 ; i < 5 ; i++) {
			System.out.println(arr[i]);
		}
		}catch(ArrayIndexOutOfBoundsException e) {
			System.err.println("Array length is less");
		}
	}
	
	public static void main(String[] args) {
		Test2 test = new Test2();
		
		test.arithematicException(50);
		test.nullPointerException(null);
		test.arrayIndexOutOfBoundsException(new int[] {2,3,4,5});
	
	}

}
