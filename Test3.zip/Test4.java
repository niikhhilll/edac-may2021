class Student{
	
	int rollNo;
	String name;
	
	void disp() {
		System.out.println("Roll no : "+rollNo);
		System.out.println("Name : "+name);
	}
	
}

class Marks extends Student{
	
	int marks;
	
	void disp() {
		System.out.println("Roll no : "+rollNo);
		System.out.println("Name : "+name);
		System.out.println("Marks : "+marks);
	}
	
}

class Result extends Marks{
	
	public Result(int rollNo,String name, int marks) {
		this.rollNo = rollNo;
		this.marks = marks;
		this.name = name;
		
	}
	
	void disp() {
		System.out.println("Roll no : "+rollNo);
		System.out.println("Name : "+name);
		System.out.println("Marks : "+marks);
		if( this.marks >= 40 ) {
			System.out.println("Result : Passed");
		}else {
			System.out.println("Result : Failed");
		}
	}
		
		
}
public class Test4 {

	public static void main(String[] args) {
		Result student = new Result(1,"Nikhil",70);
		student.disp();

	}

}
