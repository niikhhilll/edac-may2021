import java.util.*;

class Employee{
	int id;
	String name;
	
	public Employee(int id,String name) {
		this.id = id;
		this.name = name;
	}
	
	@Override
	public String toString() {
		return this.id+"  "+this.name;
	}
	
}

public class Test5 {

	
	public static void main(String[] args) {

		ArrayList <Employee>  list = new ArrayList<Employee>();
		list.add(new Employee(1,"Nikhil"));
		list.add(new Employee(2,"Mohit"));
		list.add(new Employee(3,"Kunal"));
		list.add(new Employee(4,"Piyush"));
		
		list.forEach(emp->System.out.println(emp));

	}

}
