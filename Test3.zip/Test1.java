import java.time.*;



interface time{
	
	void dispTime_inSec();
	
	void dispTime_inHrs();

}

public class Test1 implements time {

	@Override
	public void dispTime_inSec() {
		LocalDateTime t1 = LocalDateTime.now();
		System.out.println("Time in Seconds : "+t1.getSecond());
		
	}

	@Override
	public void dispTime_inHrs() {
		LocalDateTime t2 = LocalDateTime.now();
		System.out.println("Time in Hours : "+t2.getHour());
	}

	public static void main(String[] args) {
		Test1 test = new Test1();
		test.dispTime_inSec();
		test.dispTime_inHrs();
	}
}
